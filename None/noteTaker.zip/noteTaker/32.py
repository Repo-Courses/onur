import base64
from telegram import Update, ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext, ConversationHandler
from github import Github
import logging

TELEGRAM_BOT_TOKEN = '6192859310:AAFYnT5AvaO6Yq6S4Cb9WetsazPCdsx5BSs'
GITHUB_ACCESS_TOKEN = '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'
GITHUB_USERNAME = 'Repo-Courses'

github = Github(GITHUB_ACCESS_TOKEN)
github_user = github.get_user()

SELECTING_REPO, CREATING_REPO, UPLOADING_FILE = range(3)

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

def list_repositories():
    return [repo.name for repo in github_user.get_repos()]

def start(update: Update, context: CallbackContext):
    update.message.reply_text("Welcome to the Course Materials Bot!")
    return prompt_repository_selection(update, context)

def prompt_repository_selection(update: Update, context: CallbackContext):
    repositories = list_repositories()
    reply_keyboard = [repositories[i:i + 3] for i in range(0, len(repositories), 3)]
    reply_keyboard.append(['Add new repository'])
    update.message.reply_text("Select the repository:", reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True))
    return SELECTING_REPO

def handle_repository_selection(update: Update, context: CallbackContext):
    selected_repo = update.message.text
    if selected_repo == "Add new repository":
        update.message.reply_text("Enter the new repository name:", reply_markup=ReplyKeyboardRemove())
        return CREATING_REPO
    else:
        context.user_data['selected_repo'] = selected_repo
        update.message.reply_text(f"You have selected {selected_repo}. Now, send me a file or text to upload.")
        return UPLOADING_FILE

def get_mime_type(file_extension):
    mime_types = {
        "txt": "text/plain",
        "jpg": "image/jpeg",
        "jpeg": "image/jpeg",
        "png": "image/png",
        "pdf": "application/pdf",
        "py": "text/x-python",
        "html": "text/html",
        "htm": "text/html",
        "java": "text/x-java-source",
    }
    return mime_types.get(file_extension.lower(), "application/octet-stream")


def handle_upload(update: Update, context: CallbackContext) -> int:
    selected_repo = context.user_data["selected_repo"]
    repo = github_user.get_repo(selected_repo)

    try:
        if update.message.text:
            text = update.message.text
            file_name = f"{update.message.message_id}.txt"
            repo.create_file(file_name, f"Add {file_name} to {selected_repo}", text)
            update.message.reply_text("Text uploaded successfully to the selected repository!")

        elif update.message.document:
            file_id = update.message.document.file_id
            file_name = update.message.document.file_name or f"{file_id}.unknown"
            file = context.bot.get_file(file_id)
            file_content = file.download_as_bytearray()

            mime_type = get_mime_type(file_name.split(".")[-1])
            if mime_type.startswith("text/"):
                file_content = file_content.decode("utf-8")
            else:
                file_content = base64.b64encode(file_content).decode("utf-8")
                file_content = f"data:{mime_type};base64,{file_content}"

            repo.create_file(file_name, f"Add {file_name} to {selected_repo}", file_content)

            update.message.reply_text("File uploaded successfully to the selected repository!")

    except Exception as e:
        logger.error(f"An error occurred while uploading the file: {e}")
        update.message.reply_text("An error occurred while uploading the file. Please try again.")

    return SELECTING_REPO

def create_new_repo(update: Update, context: CallbackContext):
    new_repo_name = update.message.text
    new_repo = github_user.create_repo(new_repo_name)
    update.message.reply_text(f"New repository {new_repo_name} has been created.")
    return prompt_repository_selection(update, context)

def main():
    updater = Updater(TELEGRAM_BOT_TOKEN, use_context=True)
    dispatcher = updater.dispatcher

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            SELECTING_REPO: [
                MessageHandler(Filters.text & ~Filters.command, handle_repository_selection)
            ],
            CREATING_REPO: [
                MessageHandler(Filters.text & ~Filters.command, create_new_repo)
            ],
            UPLOADING_FILE: [
                MessageHandler(Filters.text | Filters.document, handle_upload)
            ],
        },
        fallbacks=[],
        allow_reentry=True,
    )

    dispatcher.add_handler(conv_handler)

    # Start the Bot
    updater.start_polling()

    # Run the bot until you press Ctrl-C or the process receives SIGINT,
    # SIGTERM or SIGABRT. This should be used most of the time, since
    # start_polling() is non-blocking and will stop the bot gracefully.
    updater.idle()

if __name__ == '__main__':
    main()

